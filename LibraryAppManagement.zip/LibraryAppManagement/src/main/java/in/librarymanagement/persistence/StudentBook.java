package in.librarymanagement.persistence;

public enum StudentBook {
	ISSUED,RETURNED;
}
