package in.librarymanagement.persistence;

public enum UpdateDB {
	INCREMENT,DECREMENT;
}
